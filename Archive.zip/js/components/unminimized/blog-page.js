(function ($) {
  'use strict';

  Berserk.behaviors.blog__page_init = {
    attach: function (context, settings) {

    }
  }
})(jQuery);